package com.gitam.springboot.StudentInventory;

public class ErrorBean {
	int erId;
	String erMes;
	public int getErId() {
		return erId;
	}
	public void setErId(int erId) {
		this.erId = erId;
	}
	public String getErMes() {
		return erMes;
	}
	public void setErMes(String erMes) {
		this.erMes = erMes;
	}
}
